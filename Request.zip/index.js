const express = require('express');
const puppeteer = require('puppeteer');

const app = express();
const PORT = 3000;

// Rota para fazer uma solicitação POST usando Puppeteer
app.get('/fazer-solicitacao', async (req, res) => {
  try {
    // Iniciar o navegador Puppeteer
    const browser = await puppeteer.launch();

    // Abrir uma nova página
    const page = await browser.newPage();

    // Configurar os cabeçalhos da solicitação
    await page.setExtraHTTPHeaders({
      'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
      'accept': 'application/json',
      'Referer': 'https://si-pni.saude.gov.br/',
      'X-Authorization': 'Basic a2V0aGVsZW4ua3RsQGdtYWlsLmNvbTpLdGxfMTIyMTA3',
      'sec-ch-ua-mobile': '?1',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      'sec-ch-ua-platform': '"Android"'
    });

    // Fazer a solicitação POST
    const response = await page.evaluate(async () => {
      const response = await fetch('https://servicos-cloud.saude.gov.br/pni-bff/v1/autenticacao/tokenAcesso', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          // Se houver dados a serem enviados no corpo da solicitação, adicione-os aqui
        })
      });
      return await response.json();
    });

    // Fechar o navegador Puppeteer
    await browser.close();

    // Enviar a resposta de volta ao cliente
    res.json(response);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro na solicitação');
  }
});

// Iniciando o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
